/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['app.nusaqu.id'],
      },
};

export default nextConfig;
